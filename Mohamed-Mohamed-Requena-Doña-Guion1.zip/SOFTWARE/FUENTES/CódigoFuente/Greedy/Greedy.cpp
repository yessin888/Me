#include <chrono>
#include "Greedy.h"

Greedy::Greedy(int tam): tam(tam), solAct(tam) {

    for (int i = 0; i < tam; i++) {
        solAct[i] = 0;
    }
    /**/
}

void Greedy::calcularMatrices(std::priority_queue<std::pair<int, int>, std::vector<std::pair<int, int>>, std::greater<std::pair<int, int>>>& distHeap,
                              std::priority_queue<std::pair<int, int>, std::vector<std::pair<int, int>>, CompareGreedy>& flujoHeap) {

    FileLoader* n = FileLoader::GetInstancia(); //obtengo instancia para acceder a datos

    int sumFlujo = 0, sumDist = 0;

    for (int i = 0; i < tam; i++) {
        for (int j = 0; j < tam; j++) {
            if (i != j) {
                sumFlujo += n->getFlujo()[i][j]; // calculo el coste de un flujo respecto a los otros
                sumDist += n->getDist()[i][j]; // calculo el coste de una distancia respecto a los otros
            }
        }

        flujoHeap.push({ sumFlujo, i }); //guardo el indice y su valor asociado del flujo
        sumFlujo = 0;
        distHeap.push({ sumDist, i }); //guardo el indice y su valor asociado de distancia
        sumDist = 0;

    }

}

int Greedy::ExecuteGreedy() {

    auto start = std::chrono::high_resolution_clock::now();

    std::priority_queue<std::pair<int, int>, std::vector<std::pair<int, int>>, CompareGreedy> flujoHeap;
    std::priority_queue<std::pair<int, int>, std::vector<std::pair<int, int>>, std::greater<std::pair<int, int>>> distHeap;

    calcularMatrices(distHeap, flujoHeap); // calculo los costes

    while (!distHeap.empty()) { // mientras no haya asignado todas las localizaciones

        int indice = distHeap.top().second; // mejor localización
        int indicef = flujoHeap.top().second; // mejor unidad

        solAct[indicef] = indice; //en la unidad unidadf(flujo) guardo la localización indice(Dist)

        flujoHeap.pop();
        distHeap.pop();

    }

    // Registra el tiempo de finalización
    auto end = std::chrono::high_resolution_clock::now();
    // Calcula la duración
    std::chrono::duration<double> duration = end - start;
    std::cout << "Tiempo de ejecucion de greedy: " << duration.count() << std::endl;

    return Auxiliar::CosteFuncion(solAct); // calculo el coste asociado a dicha solución
}



