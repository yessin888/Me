#pragma once

#include <queue>
#include <iostream>
#include "FileLoader.h"
#include <vector>
#include "CompareGreedy.h"
#include "Auxiliar.h"

class Greedy
{
private:

    std::vector<int> solAct;
    int tam; //tamaño del vector

    /*
     * Método que calcula el coste asociado de un flujo respecto al resto y lde una distancia respecto al resto
     * @param distHeap, flujoHeap: estructuras para almacenar los costes de manera ordenada
     * @post: relleno los heap pasados por cabecera con los costes calculados
     */
    void calcularMatrices(std::priority_queue<std::pair<int, int>, std::vector<std::pair<int, int>>, std::greater<std::pair<int, int>>>& distHeap,
                          std::priority_queue<std::pair<int, int>, std::vector<std::pair<int, int>>, CompareGreedy>& flujoHeap); //investigar usar vector o deque subyacentemente


public:

    Greedy(int tam);//inicializar el vector solución

    int ExecuteGreedy();

    std::vector<int>& getV() {
        return solAct;
    }





};

