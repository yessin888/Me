//
// Created by carlo on 2023/09/15.
//

#include <sstream>
#include "FileLoader.h"

FileLoader* FileLoader::cargadorArchivos = nullptr;

FileLoader::FileLoader(std::string archivoParametros) {
    std::ifstream archivo;
    archivo.open(archivoParametros);

    if (!archivo) {
        throw std::invalid_argument("Ups, no se ha podido abrir el archivo xD!");
    }

    // Leemos el archivo y pasamos al stream(mystring) su contenido
    std::string mystring, parametro, valor;
    if (archivo.is_open()) {

            while (getline(archivo, mystring) && !mystring.empty()) {
                std::istringstream linea(mystring);
                getline(linea, parametro, '=');
                getline(linea, valor);

                if(parametro == "semilla") {
                    semilla = std::stoi(valor);
                }
                if(parametro == "numParada") {
                    numParada = std::stoi(valor);
                }
                if(parametro == "algoritmo") {
                    algoritmo = valor;
                }
                if(parametro == "tenenciaTabu") {
                    tenenciaTabu = std::stoi(valor);
                }
                if(parametro == "nombreFicheroLog") {
                    nombreFicheroLog = valor;
                }
                if(parametro == "numMaxEmpeoramiento"){
                    movimientosMaxEmpeoramiento = std::stoi(valor);
                }
                if(parametro == "porcentajeOscilacion"){
                    porcentajeOscilacion = std::stoi(valor);
                }
                if(parametro == "tamGrasp") {
                    tamGrasp = std::stoi(valor);
                }
                if(parametro == "numEjecucionesGrasp") {
                    numEjecucionesGrasp = std::stoi(valor);
                }
                if(parametro == "probabilidadDLB") {
                    probabilidadDLB = std::stoi(valor);
                }

            }

    }

    // Cierro archivo
    if (archivo.is_open()) {
        archivo.close();
    }

    archivo.open(this->algoritmo); //abro archivo del algoritmo
    if (!archivo) {
        throw std::invalid_argument("Ups, no se ha podido abrir el archivo del algoritmo xD");
    }
    std::getline(archivo, mystring);
    tamDatos = std::stoi(mystring);

    // Cogemos memoria para las matrices donde se vierten los datos
    flujoProductos = new int* [tamDatos];
    distancias = new int* [tamDatos];
    for (int i = 0; i < tamDatos; i++) {
        flujoProductos[i] = new int[tamDatos];
        distancias[i] = new int[tamDatos];
    }

    std::getline(archivo, mystring); // Ignoramos línea en blanco que separa la matriz

    int i = 0;
    while (getline(archivo, mystring) && !mystring.empty()) { // Recorremos la primera matriz de flujo
        std::string numero;
        std::istringstream linea(mystring);
        int j = 0;
        while (getline(linea, numero, ' ') && i < tamDatos && j < tamDatos) {
            flujoProductos[i][j] = std::stoi(numero);
            j++;
        }
        j = 0;
        i++;
    }
    i = 0;

    while (getline(archivo, mystring) && !mystring.empty()) { // Recorremos la segunda matriz de distancias
        std::string numero;
        std::istringstream linea(mystring);
        int j = 0;
        while (getline(linea, numero, ' ') && i < tamDatos && j < tamDatos) {
            distancias[i][j] = std::stoi(numero);
            j++;
        }
        j = 0;
        i++;
    }
    i = 0;

    if(archivo.is_open()) {
        archivo.close();
    }

    movimientosMaxEmpeoramiento = (numParada * movimientosMaxEmpeoramiento) / 100; // calculo el numero maximo de iteraciones

}

FileLoader::~FileLoader() {

    // Iteramos y liberamos memoria de las matrices de datos
    for (int i = 0; i < tamDatos; i++) {
        for (int j = 0; j < tamDatos; j++) {
            delete[] distancias[i];
            delete[] flujoProductos[i];
        }
        delete[] distancias;
        delete[] flujoProductos;
    }

}

FileLoader* FileLoader::GetInstancia(std::string archivoParametros) {
    // Creamos instancia del Singleton en caso de no existir y devolvemos la existente en caso de haber sido previamente creada
    if (!cargadorArchivos) {
        cargadorArchivos = new FileLoader(archivoParametros);
        return cargadorArchivos;
    }
    else {
        return cargadorArchivos;
    }
}



void FileLoader::ToString() {
    std::cout << "algoritmo: " << algoritmo << std::endl;
    std::cout << "El tamaño de las matrices: " << tamDatos << std::endl;

    std::cout << "Matriz de flujos: " << std::endl;
    for (int i = 0; i < tamDatos; i++) {
        for (int j = 0; j < tamDatos; j++) {
            std::cout << flujoProductos[i][j] << " ";
        }
        std::cout << " " << std::endl;
    }
    std::cout << " " << std::endl;

    std::cout << "Matriz de distancia: " << std::endl;
    for (int i = 0; i < tamDatos; i++) {
        for (int j = 0; j < tamDatos; j++) {
            std::cout << distancias[i][j] << " ";
        }
        std::cout << " " << std::endl;
    }

    std::cout << "Semilla: " << semilla << std::endl;
    std::cout << "numParada: " << numParada << std::endl;

}


