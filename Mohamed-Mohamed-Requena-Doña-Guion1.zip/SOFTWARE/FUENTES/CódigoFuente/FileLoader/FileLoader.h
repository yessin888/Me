//
// Created by carlo on 2023/09/15.
//

#ifndef SEMINARIO_2_FILELOADER_H
#define SEMINARIO_2_FILELOADER_H

#include <string>
#include <fstream>
#include <iostream>

class FileLoader {

private:
    static FileLoader* cargadorArchivos;
    int tamDatos;
    int** flujoProductos;
    int** distancias;

    int semilla;
    int numParada;
    std::string algoritmo;
    int tenenciaTabu;
    std::string nombreFicheroLog;
    int movimientosMaxEmpeoramiento;
    int porcentajeOscilacion;
    int numEjecucionesGrasp;
    int tamGrasp;
    int probabilidadDLB;



public:
    FileLoader(std::string archivoParametros );
    FileLoader(const FileLoader& obj) = delete;
    static FileLoader* GetInstancia(std::string archivoParametros = "");
    ~FileLoader();
    void ToString();

    int getTamDatos() const{
        return tamDatos;
    }

    int** getFlujo() {
        return flujoProductos;
    }

    int** getDist() {
        return distancias;
    }

    int getSemilla() const {
        return semilla;
    }

    int getNumParada() const {
        return numParada;
    }

    int getTenenciaTabu() const {
        return tenenciaTabu;
    }

    const std::string &getNombreFicheroLog() const {
        return nombreFicheroLog;
    }

    const std::string &getAlgoritmo() const {
        return algoritmo;
    }

    int getMovimientosMaxEmpeoramiento() const {
        return movimientosMaxEmpeoramiento;
    }

    int getPorcentajeOscilacion() const {
        return porcentajeOscilacion;
    }

    int getNumEjecucionesGrasp() const {
        return numEjecucionesGrasp;
    }

    int getTamGrasp() const {
        return tamGrasp;
    }

    int getProbDLB() const {
        return probabilidadDLB;
    }

};


#endif //SEMINARIO_2_FILELOADER_H
