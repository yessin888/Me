#pragma once

#include <vector>
#include "Auxiliar.h"
#include <bitset>
#include <fstream>

class BusquedaLocal
{
public:
    BusquedaLocal(std::vector<int> &vIni);
    ~BusquedaLocal();
    int executeBusquedaLocal();


private:
    std::vector<int> solAct;
    std::vector<bool> DLB;
    int valorActual;
    int tamSolAct;
    std::ofstream log;

    /*
     * Compruebo si mejoro la solución actual
     * @param i, j: posiciones para hacer swap y generar nueva posición
     * @post: actualizo la solución actual y su valor si mejora el vecino
     * @return: bool indicando si he mejorado la solución actual o no
     */
    bool factible(int i, int j);

    /*
     * Genero vecinos buscando uno que mejore la solución actual
     * @param valorDLBInicio: posición a partir de la cual se empieza la exploración
     * @post: actualizo la solución actual y su valor si mejora el vecino
     * @return: bool indicando si he mejorado la solución actual o no
     */
    bool generaVecino(int valorDLBInicio);
};

