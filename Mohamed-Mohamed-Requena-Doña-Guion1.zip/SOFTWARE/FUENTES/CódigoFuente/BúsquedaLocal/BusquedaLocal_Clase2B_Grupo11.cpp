#include <chrono>
#include "BusquedaLocal.h"

BusquedaLocal::BusquedaLocal(std::vector<int> &vIni): tamSolAct(FileLoader::GetInstancia()->getTamDatos()), DLB(FileLoader::GetInstancia()->getTamDatos()) {
    FileLoader* n = FileLoader::GetInstancia();
    solAct = vIni; //inicializo el vector con valores de la solución greedy
    valorActual = Auxiliar::CosteFuncion(solAct); //Inicializo el coste
    log.open("RESULTADOS/" + n->getNombreFicheroLog() + "_BusquedaLocal" + n->getAlgoritmo() + "-" + std::to_string(n->getSemilla()) + ".txt");
    log << "Busqueda Local" << "\n" << "****Datos fichero parámetro**** " << std::endl;
    log << "Semilla: " << n->getSemilla() << "\n" << "numParada: " << n->getNumParada() << "\n"
        << "Conjunto de datos: " <<  n->getAlgoritmo() << std::endl;
    log << "\n" << "Solución inicial: " <<std::endl;
    for(int i = 0; i < tamSolAct; i++) {
        DLB[i] = false;
        log << solAct[i] << " ";
    }

    log << "\n" << "Valor inicial: " << valorActual  << "\n" << std::endl;
}
BusquedaLocal::~BusquedaLocal() {
    if (log.is_open()) {
        log.close();
    }
}

int BusquedaLocal::executeBusquedaLocal() {

    auto start = std::chrono::high_resolution_clock::now();

    FileLoader* n = FileLoader::GetInstancia();

    bool mejora = true;
    int c = 0;
    int valorInicioDLB = 0;

    while ( mejora && c < n->getNumParada() ) {

        log << "ITERACIÓN: " << c << std::endl;

        valorInicioDLB = Auxiliar::getRandom(); //establezco la posición de inicio de exploración

        bool success =  generaVecino(valorInicioDLB); //genero un nuevo vecino

        if (!success) {
            mejora = false;
        }
        c++;//aumento contador de vueltas
    }

    log << "\n" << "Número total de vueltas: " << c << std::endl;
    log << "Mejor solución obtenida: " << valorActual << std::endl;
    for(int i = 0; i < tamSolAct; i++) {
        log << solAct[i] << " " ;
    }
    log << "\n" << "Estado final de DLB: " << std::endl;
    for(int i = 0; i < tamSolAct; i++) {
        if(DLB[i])
            log << 1 << " " ;
        else
            log << 0 << " " ;
    }
    log << "" << std::endl;

    // Registra el tiempo de finalización
    auto end = std::chrono::high_resolution_clock::now();
    // Calcula la duración
    std::chrono::duration<double> duration = end - start;
    log << "Tiempo de ejecución de búsqueda local: " << duration.count() << std::endl;

    return valorActual;

}

bool BusquedaLocal::generaVecino(int valorDLBInicio) {
    //uso el operador '%' con i y j para simular un vector cíclico
    bool mejora = false;
    int i = valorDLBInicio;

    do{
        if( !DLB[i % tamSolAct] ){ // si DLB[i] es == 0

            mejora = false;
            int j = i+1;
            do{
                bool move = factible(i % tamSolAct,j % tamSolAct); // compruebo si el movimiento es factible,
                                                                        // en caso afirmativo aplico el movimiento
                if ( move ) {
                    log << "Pongo a 0 en la dlb, las posiciones: " << i%tamSolAct << "-" << j%tamSolAct << std::endl;
                    DLB[i % tamSolAct] = DLB[j%tamSolAct] = false;
                    mejora = true;
                    return true;

                }

                j++;

            } while ( ((j-1) % tamSolAct) != valorDLBInicio );

            if( !mejora ) {
                log << "No hay mejora en la posición: " << i%tamSolAct << " ,por lo que DLB a 1" << std::endl;
                DLB[i % tamSolAct] = true;
            }

        } //endif
        i++;
    }while( (i % tamSolAct) != valorDLBInicio) ;

    return false; // no se ha encontrado vecino
}

bool BusquedaLocal::factible(int i, int j) {
    std::vector<int> vecino = solAct;

    log << "Genero vecino( swap " << i << "-" << j << " )" <<std::endl;

    int aux = vecino[j];
    vecino[j] = vecino[i];
    vecino[i] = aux; //genero un vecino haciendo el swap

    int costeVecino = 0;
    FileLoader* n = FileLoader::GetInstancia();
    for(int x = 0; x < tamSolAct; x++){
        log << vecino[x] << " ";
        if (x != i && x != j){
            costeVecino += n->getFlujo()[i][x] * (n->getDist()[vecino[i]][vecino[x]] - n->getDist()[solAct[i]][solAct[x]]) * 2;
            costeVecino += n->getFlujo()[j][x] * (n->getDist()[vecino[j]][vecino[x]] - n->getDist()[solAct[j]][solAct[x]]) * 2;
        }
    }
    costeVecino = valorActual + costeVecino; // calculo el coste
    log << "\n" << "Coste del vecino: "  << costeVecino << std::endl;

    if(costeVecino < valorActual){ // si mejoro actualizo las solAct y su valor
        log << "Este vecino mejora el valorActual: " << valorActual << " por tanto me muevo al vecino" << std::endl;
        aux = solAct[j];
        solAct[j] = solAct[i];
        solAct[i] = aux;

        this->valorActual = costeVecino;
        return true;
    }
    return false;
}
