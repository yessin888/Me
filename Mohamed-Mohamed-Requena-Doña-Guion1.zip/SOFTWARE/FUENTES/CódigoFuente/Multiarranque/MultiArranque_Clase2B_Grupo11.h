//
// Created by yessi on 21/10/2023.
//

#ifndef PR1META_MULTIARRANQUE_H
#define PR1META_MULTIARRANQUE_H


#include <queue>
#include "CompareGreedy.h"
#include "Auxiliar.h"
#include "BusquedaTabu.h"
#include "chrono"

class MultiArranque {
private:

    std::vector<int> solAct;
    int valorActual;
    int valorGlobal;
    std::vector<int> solGlobal;
    std::ofstream log;
    /*
     * Método que calcula el coste asociado de un flujo respecto al resto y lde una distancia respecto al resto
     * @param distHeap, flujoHeap: estructuras para almacenar los costes de manera ordenada
     * @post: relleno los heap pasados por cabecera con los costes calculados
     */
    void calcularMatrices(std::priority_queue<std::pair<int, int>, std::vector<std::pair<int, int>>, std::greater<std::pair<int, int>>>& distHeap,
    std::priority_queue<std::pair<int, int>, std::vector<std::pair<int, int>>, CompareGreedy>& flujoHeap);

    /*
     * Genero una nueva solución tomando las mejores locaclizaciones y unidades de manera aleatoria entre las mejores localizaciones
     *
     */
    void grasp();

public:
    MultiArranque();
    ~MultiArranque();
    int executeMultiArranque();

};


#endif //PR1META_MULTIARRANQUE_H
