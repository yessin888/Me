//
// Created by yessi on 21/10/2023.
//

#include "MultiArranque.h"
#include "FileLoader.h"

MultiArranque::MultiArranque() {
    FileLoader* n = FileLoader::GetInstancia();
    int tam = n->getTamDatos();
    solAct.resize(tam);
    valorGlobal = INT_MAX;
    for (int i = 0; i < tam; i++) {
        solAct[i] = 0;
    }


    log.open("RESULTADOS/Multiarranque_salida" + n->getAlgoritmo() + "-" + std::to_string(n->getSemilla()) + ".txt"); //abro fichero Log
    log << "MUltiarranque" << "\n" << "****Datos fichero parámetro**** " << std::endl;
    log << "Semilla: " << n->getSemilla() << "\n" << "numParada: " << n->getNumParada() << "\n"
        << "Tenencia Tabú: " << n->getTenenciaTabu() << "\n"
        << "movimientosMaxEmpeoramiento( calculado respecto a numParada) : " << n->getMovimientosMaxEmpeoramiento() << "\n"
        << "porcentaje de probabilidad en oscilación: " << n->getPorcentajeOscilacion() << "\n"
        << "Conjunto de datos: " <<  n->getAlgoritmo() << "\n"
        << "Vueltas de multiarranque: " <<  n->getNumEjecucionesGrasp() << "\n"
        << "Grasp rango: " <<  n->getTamGrasp()<< std::endl;

}

MultiArranque::~MultiArranque() {
    if (log.is_open()) {
        log.close(); // cierro el fichero Log
    }
}

int MultiArranque::executeMultiArranque() {

    auto start = std::chrono::high_resolution_clock::now();

    int numExecutes = FileLoader::GetInstancia()->getNumEjecucionesGrasp();
    int tam = FileLoader::GetInstancia()->getTamDatos();

    for (int i = 0; i < numExecutes; ++i) {

        grasp(); // genero una nueva solución inicial con el grasp
        log<< "Genero una nueva sol grasp: " ;
        log << valorActual << std::endl;

        for (int j = 0; j < tam; ++j) {
            log << solAct[j] << " ";
        }
        log<< "\n" <<std::endl;

        // Ejecuto una búsqueda tabú desde la nueva solución inicial generada
        BusquedaTabu *bt = new BusquedaTabu(solAct,"BUSQUEDA_TABU_MULTIARRANQUE/multiarranqueIt" + std::to_string(i) + "_salida.txt" );
        int valor = bt->executeBusquedaTabu();

        log << "Valor obtenido de búsqueda tabú: " << valor << std::endl;

        if( valor < valorGlobal ) { // si esa busqueda tabú mejora la solución, actualizo
            log << "He mejorado la solución: " << valorGlobal << " -> " << valor <<std::endl;
            valorGlobal = valor;
            solGlobal = bt->getMejorGlobal();
        }

        delete bt;
    }
    log << "La mejor solución global obtenida es: " << valorGlobal << std::endl;

    for (int j = 0; j < tam; ++j) {
        log << solGlobal[j] << " ";
    }

    // Registra el tiempo de finalización
    auto end = std::chrono::high_resolution_clock::now();
    // Calcula la duración
    std::chrono::duration<double> duration = end - start;
    log << "\nTiempo de ejecución de bt: " << duration.count() << std::endl;

    return valorGlobal;

}

void MultiArranque::calcularMatrices(std::priority_queue<std::pair<int, int>, std::vector<std::pair<int, int>>, std::greater<std::pair<int, int>>>& distHeap,
std::priority_queue<std::pair<int, int>, std::vector<std::pair<int, int>>, CompareGreedy>& flujoHeap) {

    FileLoader *n = FileLoader::GetInstancia(); //obtengo instancia para acceder a datos
    int tam = n->getTamDatos();
    int sumFlujo = 0, sumDist = 0;

    for (int i = 0; i<tam; i++) {
        for (int j = 0; j<tam; j++) {
            if (i != j) {
                sumFlujo += n->getFlujo()[i][j]; // calculo el coste de un flujo respecto a los otros
                sumDist += n->getDist()[i][j];   // calculo el coste de una distancia respecto a los otros
            }
        }

        flujoHeap.push({sumFlujo, i }); //guardo el indice y su valor asociado del flujo
        sumFlujo = 0;
        distHeap.push({sumDist, i }); //guardo el indice y su valor asociado de distancia
        sumDist = 0;

    }

}

void MultiArranque::grasp() {

    std::priority_queue<std::pair<int, int>, std::vector<std::pair<int, int>>, CompareGreedy> flujoHeap;
    std::priority_queue<std::pair<int, int>, std::vector<std::pair<int, int>>, std::greater<std::pair<int, int>>> distHeap;

    calcularMatrices(distHeap, flujoHeap);

    FileLoader* n = FileLoader::GetInstancia();
    std::vector<std::pair<int,int>> auxFlujo;
    std::vector<std::pair<int,int>> auxDist;

    while (!distHeap.empty()) {

        int rangoRandom = n->getTamGrasp(); // se elije una de los 'n->getTamGrasp()' mejores localizaciones
        if( distHeap.size() < rangoRandom ) {
            rangoRandom = distHeap.size(); // si ese rango de localizaciones a tener en cuenta es superior al numero de elementos sina signar => el rango es distHeap.size()
        }
        int randomFlujo = Auxiliar::getRandom(rangoRandom); //[0-9]
        int randomDist = Auxiliar::getRandom(rangoRandom); //[0-9]

        for(int i = 0; i <= randomFlujo; i++) {
            auxFlujo.push_back(flujoHeap.top()); // como no se puede iterrar el heap los saco hasta randomFlujo y almaceno, para después volver a insertar lo sacado
            flujoHeap.pop();
        }
        for(int i = 0; i <= randomDist; i++) {
            auxDist.push_back(distHeap.top()); // como no se puede iterrar el heap los saco hasta randomDist y almaceno, para después volver a insertar lo sacado
            distHeap.pop();
        }

        int indice = auxDist[randomDist].second; // la localización
        int indicef = auxFlujo[randomFlujo].second; // la unidad

        solAct[indicef] = indice; //en la unidad unidadf(randomFlujo) guardo la localización indice(randomDist)

        for (int i = 0; i < randomFlujo; ++i) {
            flujoHeap.push(auxFlujo[i]); // devuelvo los elementos al heap
        }
        for (int i = 0; i < randomDist; ++i) {
            // devuelvo los elementos al heap
            distHeap.push(auxDist[i]);
        }

        auxFlujo.clear();
        auxDist.clear();

    }
    valorActual = Auxiliar::CosteFuncion(solAct);

}