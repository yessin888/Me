#include <iostream>
#include "FileLoader.h"
#include <string>
#include "Greedy.h"
#include "Auxiliar.h"
#include "BusquedaLocal.h"
#include "BusquedaTabu.h"
#include "MultiArranque.h"
#include <fstream>

int main() {


    try {
        std::string archivoParam = "../FUENTES/parametros.txt";
        FileLoader* loader = FileLoader::GetInstancia(archivoParam);
        std::srand(loader->getSemilla()); // establezco semilla

        Greedy dr(loader->getTamDatos());
        int x = dr.ExecuteGreedy();
        std::cout << "solucion coste greedy-> " << x << std::endl;
        std::srand(loader->getSemilla()); // establezco semilla

        BusquedaLocal* bl = new BusquedaLocal(dr.getV());
        std::cout << "solucion coste busqueda Local-> " << bl->executeBusquedaLocal() << std::endl;
        std::srand(loader->getSemilla()); // establezco semilla
        delete bl;

        BusquedaTabu* bt = new BusquedaTabu(dr.getV(), "BusquedaTabu_salida.txt");
        std::cout << "solucion coste busquedaTabú-> " << bt->executeBusquedaTabu() << std::endl;
        std::srand(loader->getSemilla()); // establezco semilla
        delete bt;

        MultiArranque* bm = new MultiArranque();
        std::cout << "solucion coste multiarranque-> " << bm->executeMultiArranque() << std::endl;
        delete bm;

    }
    catch (const std::exception& e) {
        std::cout << e.what();
    }


    std::cin.get(); // Espera a que el usuario presione Enter

    return 0;
}
