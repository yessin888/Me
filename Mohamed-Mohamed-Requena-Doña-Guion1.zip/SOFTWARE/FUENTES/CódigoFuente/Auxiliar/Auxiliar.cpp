#include "Auxiliar.h"

int Auxiliar::CosteFuncion( std::vector<int>& v ) {

    int c = 0;
    FileLoader* n = FileLoader::GetInstancia();
    int tam = n->getTamDatos();

    for (int i = 0; i < tam; i++) {
        for (int j = 0; j < tam; j++) {
            if (i != j) {
                c += n->getFlujo()[i][j] * n->getDist()[v[i]][v[j]]; // calculo el coste
            }
        }
    }
    return c;
}

int Auxiliar::getRandom() {
    FileLoader* n = FileLoader::GetInstancia();
    int tam = n->getTamDatos();
    return std::rand() % (tam);
}

int Auxiliar::getRandom(int limite) {
    return std::rand() % (limite);
}

