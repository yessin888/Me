#pragma once

#include <set>
#include "FileLoader.h"
#include <vector>
#include <stdlib.h>

class Auxiliar
{
public:
    /*
     * Calcula el coste del vector pasado por parámetro
     * @return devuelve el coste del vector
     */
    static int CosteFuncion( std::vector<int>& v );

    /*
     * genero un valor random entre [0-tam]
     */
    static int getRandom();

    /*
     * genero un valor random dentro de un rango
     * @param limite: marca el límite superior
     */
    static int getRandom(int limite);

};

