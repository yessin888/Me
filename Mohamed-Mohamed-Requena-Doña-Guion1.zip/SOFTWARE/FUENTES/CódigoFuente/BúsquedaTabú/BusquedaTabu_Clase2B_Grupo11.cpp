//
// Created by yessi on 05/10/2023.
//

#include <queue>
#include <chrono>
#include "BusquedaTabu.h"
#include "FileLoader.h"
#include "Auxiliar.h"
//todo en el log decir si la oscilacion ha funcionado bien
BusquedaTabu::BusquedaTabu(std::vector<int>& vIni, std::string nombreLog): tamSolAct(FileLoader::GetInstancia()->getTamDatos()), DLB(FileLoader::GetInstancia()->getTamDatos()) {
    FileLoader* n = FileLoader::GetInstancia();
    solAct = vIni; //inicializo la solución inicial
    mejorMomento = vIni; // inicializo la mejor solución del momento
    mejorGlobal = vIni; // inicializo la mejor solución global
    solucionEjecucionAnterior = vIni;
    valorEjecucionAnterior = -1;
    valorActual = Auxiliar::CosteFuncion(solAct); // calculo el coste de la solución actual
    valorMejorMomento = valorActual;
    valorMejorGlobal = valorActual;
    estancamiento = 0;

    tenenciaTabu = FileLoader::GetInstancia()->getTenenciaTabu();
    memMovimientos.resize(tamSolAct, std::vector<int>(tamSolAct)); //establezo la matriz de tam NxN
    memLargoPlazo.resize(tamSolAct, std::vector<int>(tamSolAct)); //establezo la matriz de tam NxN
    memSoluciones.resize(tenenciaTabu, std::vector<int>(tamSolAct)); // establezco la matriz de tam MxN, M(tenencia tabu)

    log.open("RESULTADOS/" + nombreLog); //abro fichero Log
    log << "Busqueda Tabú" << "\n" << "****Datos fichero parámetro**** " << std::endl;
    log << "Semilla: " << n->getSemilla() << "\n" << "numParada: " << n->getNumParada() << "\n"
        << "Tenencia Tabú: " << n->getTenenciaTabu() << "\n"
        << "movimientosMaxEmpeoramiento( calculado respecto a numParada) : " << n->getMovimientosMaxEmpeoramiento() << "\n"
        << "porcentaje de probabilidad en oscilación: " << n->getPorcentajeOscilacion() << "\n"
        << "Conjunto de datos: " <<  n->getAlgoritmo() << std::endl;
    log << "\n" << "Solución inicial: " <<std::endl;


    for(int i = 0; i < tamSolAct; i++) {
        for(int j = 0; j < tamSolAct; j++){
            memLargoPlazo[i][j] = 0; // inicializo la matriz a 0
            memMovimientos[i][j] = 0; // inicializo la matriz a 0
        }
        DLB[i] = false; //incializo DLB
        log << solAct[i] << " "; // muestro solución en el Log
    }

    log << "\n" << "Valor inicial: " << valorActual  << "\n" << std::endl; // muestro el valor de la solAct

    for(int i = 0; i < tenenciaTabu; i++) {
        for(int j = 0; j < tamSolAct; j++){
            memSoluciones[i][j] = 0;
        }

    }

}

BusquedaTabu::~BusquedaTabu() {
    if (log.is_open()) {
        log.close(); // cierro el fichero Log
    }
}

int BusquedaTabu::executeBusquedaTabu() {

    auto start = std::chrono::high_resolution_clock::now();

    FileLoader* n = FileLoader::GetInstancia();
    int c = 0; //contador de ejecuciones
    int posActual = 0; // almacena el índice de la posición en la que voy insertando valores en la memoria de soluciones tabú. Se recorre cíclicamente
    int valorInicioDLB = 0; // valor que tomará la 'i' en la exploración de vecinos
    std::vector<int> mejorPeor = solAct;
    int valorMejorPeor = INT_MAX;
    int posI, posJ; //posiciones que representan el movimiento a insertar en la lista tabú

    while ( c < n->getNumParada() ) {
        std::vector<int> mejorPeor = solAct; // reinicio el mejorPeor
        int valorMejorPeor = INT_MAX; // reinicio su valor
        posI = posJ = -1; // reinicio valor

        printMemoriasTabu(c); // muestra información en el log

        if( estancamiento >= n->getMovimientosMaxEmpeoramiento() ){ // si estancamiento -> reinicio atributos, estructuras y oscilo
            posActual = 0;
            oscilacion();
            mejorPeor = solAct;
            valorMejorPeor = INT_MAX;
        }

        valorInicioDLB = Auxiliar::getRandom(); //establezco la posición de inicio de exploración de manera aleatoria
        bool mejoraSolAct = generaVecino(valorInicioDLB, mejorPeor, valorMejorPeor, posI, posJ); //genero un nuevo vecino
        if(!mejoraSolAct) {
            // si no he mejorado solAct me muevo al mejorPeor
            movermeAMejorPeor(mejorPeor,valorMejorPeor);
            estancamiento++; // No mejoro el mejor del momento

            log << "Estancamiento: " << estancamiento << std::endl;
        }else{
            // Compruebo si esta nueva solAct es mejor que la del mejor del momento y la mejor global
            if( valorMejorPeor != INT_MAX && !actualizarValorDelMejor() ){
                estancamiento++; // No hay mejora de la mejor del momento
                log << "Estancamiento: " << estancamiento << std::endl;
            }

        }


        if( !posicionesConTabuActiva.empty() )
            decrementarTenenciaTabu();

        if(posI != -1 && posJ != -1) { // si he encontrado una solución -> posI y posJ != -1

            actualizarMemorias(posI, posJ, mejoraSolAct, mejorPeor, posActual);
            posActual++; // como he insertado una solución tabú en el índice 'posActual', la siguiente solución se inserta en 'posActual+1'

        }

        c++;//aumento contador de vueltas
    }

    printSolucion(c); // información que muestro en el log

    // Registra el tiempo de finalización
    auto end = std::chrono::high_resolution_clock::now();
    // Calcula la duración
    std::chrono::duration<double> duration = end - start;
    log << "Tiempo de ejecución de la búsqueda tabú: " << duration.count() << std::endl;


    return valorMejorGlobal;
}

bool BusquedaTabu::generaVecino(int indiceDLBInicio, std::vector<int>& mejorPeor, int& valorMejorPeor, int& parI, int& parJ) {
    //uso el operador '%' con i y j para simular un vector cíclico
    bool mejora = false;
    int i = indiceDLBInicio;
    bool tabu = false;

    do{
        if( !DLB[i % tamSolAct] ){ // si es == 0

            mejora = false;
            int j = i+1;
            do{

                int coste = factible(i % tamSolAct,j % tamSolAct); // calculo coste de hacer movimiento
                if ( coste < valorActual ) { //compruebo si es factible

                    log << "Dicho vecino mejora el coste asociado a solAct: " << valorActual << std::endl;
                    tabu = Tabu(i % tamSolAct, j % tamSolAct); //compruebo si es tabú el movimiento
                    if(!tabu) { // compruebo que no sea tabú

                        log << "Dicho vecino además No es tabú, por tanto me muevo a él" << std::endl;
                        aplicarMovimiento(i % tamSolAct, j % tamSolAct, coste, solAct, valorActual);
                        DLB[i % tamSolAct] = DLB[j % tamSolAct] = false; // actualizo DLB -> 0
                        mejora = true;
                        parI = i % tamSolAct; // almaceno la posición correspondiente al vecino
                        parJ = j % tamSolAct;
                        return true; // se ha mejorado

                    }
                }else{ //en caso de no mejorar la solAct compruebo si es el mejor peor

                    log << "Dicho vecino NOOO mejora el coste asociado a solAct: " << valorActual << std::endl;
                    tabu = Tabu(i % tamSolAct, j % tamSolAct); //compruebo si es tabú el movimiento
                    if( !tabu && coste < valorMejorPeor ) {

                        log << "Dicho vecino NO es tabú y mejora el mejorPeor. Actualizo el mejorPeor: " << valorMejorPeor << " -> " << coste << "\nMejorPeor: ";
                        mejorPeor = solAct; // me tengo que mover a un vecino de 'solAct' no de 'mejorPeor', por eso tengo que aplicar el movimineto partiendo de 'solAct'
                        aplicarMovimiento(i % tamSolAct, j %tamSolAct, coste, mejorPeor, valorMejorPeor);
                        parI = i % tamSolAct; // almaceno la posición correspondiente al vecino
                        parJ = j % tamSolAct;
                        for(int is = 0; is < tamSolAct; is++) {
                            log << mejorPeor[is] << " " ;
                        }
                        log << std::endl;

                    }else{
                        if(!tabu)
                            log << "Dicho vecino no mejora el mejorPeor: " << valorMejorPeor << std::endl;
                    }
                }
                j++;

            } while (((j-1) % tamSolAct) != indiceDLBInicio );

            if( !mejora ) {
                DLB[i % tamSolAct] = true;
            }

        } //endif DLB != 1
        i++;
    }while((i % tamSolAct) != indiceDLBInicio);

    return false; // no se ha encontrado un vecino mejor solAct

}

int BusquedaTabu::factible(int i, int j) {
    std::vector<int> vecino = solAct;
    log << "\n" << "Genero vecino( swap " << i << "-" << j << " )" <<std::endl;

    int aux = vecino[j];
    vecino[j] = vecino[i];
    vecino[i] = aux; // genero un nuevo vecino con el swap

    int costeVecino = 0;
    FileLoader* n = FileLoader::GetInstancia();
    for(int x = 0; x < tamSolAct; x++){
        log << vecino[x] << " ";
        if (x != i && x != j){
            costeVecino += n->getFlujo()[i][x] * (n->getDist()[vecino[i]][vecino[x]] - n->getDist()[solAct[i]][solAct[x]]) * 2;
            costeVecino += n->getFlujo()[j][x] * (n->getDist()[vecino[j]][vecino[x]] - n->getDist()[solAct[j]][solAct[x]]) * 2;
        }
    }
    costeVecino = valorActual + costeVecino; // calcular coste del vecino
    log << "\n" << "Coste del vecino: "  << costeVecino << std::endl;

    return costeVecino;

}

void BusquedaTabu::aplicarMovimiento(int i, int j, int coste, std::vector<int>& vCompare, int &valorCompare) {

    int aux = vCompare[j];
    vCompare[j] = vCompare[i];
    vCompare[i] = aux;

    valorCompare = coste;

}

bool BusquedaTabu::Tabu(int iSwap, int jSwap) {

    bool igual = true;
    std::vector<int> vecino = solAct;
    int aux = vecino[jSwap];
    vecino[jSwap] = vecino[iSwap];
    vecino[iSwap] = aux;

    if(memMovimientos[iSwap][jSwap] != 0){
        log << "El movimiento dado por " << iSwap << "-" << jSwap << " es tabú" << std::endl;
        return true;
    }

    for ( int i = 0; i < tenenciaTabu; i++){
        for (int j = 0; j < tamSolAct; j++) {
            if(memSoluciones[i][j] != vecino[j]){ // compruebo si el movimiento i,j es tabú
                igual = false;
            }
        }

        if(igual){ // si 'igual' sigue siendo true -> las soluciones son iguales
            log << "Esta solución es tabú" << std::endl;
            return true;
        }

        igual = true;

    } //end for i

    return false;

}

void BusquedaTabu::decrementarTenenciaTabu() {
    std::set<std::pair<int, int>> elementosAEliminar;

    //recorro el conjunto de posiciones con tenencia tabú activa
    for(std::set<std::pair<int,int>>::iterator it = posicionesConTabuActiva.begin(); it != posicionesConTabuActiva.end(); ++it ) {

        int posI = it->first;
        int posJ = it->second;

        if( memMovimientos[posI][posJ] == 1 ){ // En caso de que se acabe la tenencia tabú la pongo a 0
            memMovimientos[posI][posJ] = 0;
            elementosAEliminar.insert(*it);
        }else{
            memMovimientos[posI][posJ]--; // decremento la tenencia tabú actual
        }

    }

    //bucle for-each que elimina las posiciones que ya no poseen tenencia tabú de la estructura auxiliar
    for (const auto& elemento : elementosAEliminar) {
        log << "El movimiento: " << elemento.first << "-" << elemento.second << " ya no es tabú" << std::endl;
        posicionesConTabuActiva.erase(elemento);
    }

}

void BusquedaTabu::generaDLBRandom() {

    int probabilidad;
    FileLoader* n = FileLoader::GetInstancia();

    for(int i = 0; i < DLB.size(); i++ ){

        probabilidad = Auxiliar::getRandom(10);

        if( probabilidad < n->getProbDLB() ) // probabilidad de 'probabilidadDLB'' de de ser 0 o 1 la DLB
            DLB[i] = true;
        else
            DLB[i] = false;

    }

}

void BusquedaTabu::actualizarMemorias(int posI, int posJ, bool mejoraSolAct, std::vector<int>& mejorPeor, int posActual) {

    FileLoader* n = FileLoader::GetInstancia();

    memMovimientos[posI][posJ] = n->getTenenciaTabu(); // marco el movimiento tabú teniendo en cuneta la tenencia tabú
    this->posicionesConTabuActiva.insert(std::pair<int, int>(posI, posJ)); // marco que dichas posiciones son tabú activas

    log << "Actualizo la memoria de movimientos tabú con: " << posI << "-" << posJ << std::endl;
    log << "Actualizo la memoria de soluciones tabú y en largo plazo con: " << std::endl;

    if(mejoraSolAct){ //si he mejorado solAct

        for(int i = 0; i < tamSolAct; i++){
            log << solAct[i] << " ";
        }
        memSoluciones[posActual % n->getTenenciaTabu()] = solAct; //almaceno solAct en la memoria tabú de soluciones
        actualizarMemLargoPlazo(solAct); // actualizo la memoria a largo plazo

    }else{

        for(int i = 0; i < tamSolAct; i++){
            log << mejorPeor[i] << " ";
        }
        memSoluciones[posActual % n->getTenenciaTabu()] = mejorPeor; //almaceno el mejorPeor en la memoria tabú de soluciones
        actualizarMemLargoPlazo(mejorPeor);

    }
    log << "\n" << std::endl;
}

void BusquedaTabu::oscilacion() {

    log << "Ha habido un estancamiento" << std::endl;
    if(valorEjecucionAnterior != -1) { // compruebo que no estoy en la primera "exploración"

        if (valorEjecucionAnterior > valorActual) {
            log << "Esta oscialción ha mejorado la solución anterior: " << valorEjecucionAnterior << " -> "
                << valorActual << std::endl;
        } else {
            log << "Esta oscialción NOO ha mejorado la solución anterior: " << valorEjecucionAnterior << " -> "
                << valorActual << std::endl;
        }

    }
    log << "Como ha habido un estancamiento hago OSCILAZIÓN de nuevo" << std::endl;

    valorEjecucionAnterior = valorActual; // como voy a oscilar y a entrar en una nueva "exploración" actualizo la solución anterior
    solucionEjecucionAnterior = solAct;


    FileLoader* n = FileLoader::GetInstancia();
    int valorRandom = Auxiliar::getRandom(10); // random en un rango [0-9]
    int probabilidad = (10 * n->getPorcentajeOscilacion() / 100);

    if( valorRandom < probabilidad ){
        log << "INTENSIFICO -> " << "valor random: " << valorRandom << " < " << "probabilidad: " << probabilidad << std::endl;
        intensificar();
    }else{
        log << "DIVERSIFICO -> " << "valor random: " << valorRandom << " >= " << "probabilidad: " << probabilidad << std::endl;
        diversificar();
    }

    //REINICIO ESTRUCTURAS Y ATRIBUTOS
    log << "reinicio de las estructuras(DLB, memorias y otros) y atributos" << std::endl;
    for(int i = 0; i < tamSolAct; i++) {
        for(int j = 0; j < tamSolAct; j++){
            memLargoPlazo[i][j] = 0;
            memMovimientos[i][j] = 0; // inicializo la matriz a 0
        }
        DLB[i] = false; //incializo DLB
    }

    for(int i = 0; i < tenenciaTabu; i++) {
        for(int j = 0; j < tamSolAct; j++){
            memSoluciones[i][j] = 0;
        }

    }

    mejorMomento = solAct;
    valorMejorMomento = valorActual;
    posicionesConTabuActiva.clear();
    estancamiento = 0;


}

void BusquedaTabu::actualizarMemLargoPlazo(std::vector<int>& v) {

    for(int i = 0; i < tamSolAct; i++) {
        (memLargoPlazo[i][v[i]])++;
    }

}

void BusquedaTabu::intensificar() {
    log << "solAct Antesssss" << std::endl;

    for(int i = 0; i < tamSolAct; i++) {
        log << solAct[i] << " ";
    }

    std::vector<bool> vectorMarcaje(tamSolAct); // vector para evitar poner dos localizaciones en la misma unidad
    int LocalizacionMasVisitada, unidadCorrespondiente, masVisitado = -1; // atributos de marcaje del más visitado
    for(int i = 0; i < tamSolAct; i++){
        vectorMarcaje[i] = true; // inicializo el vector de marcaje
    }

    for(int j = 0; j < tamSolAct; j++){
        for(int i = 0; i < tamSolAct; i++) {
            if( vectorMarcaje[i] && memLargoPlazo[i][j] > masVisitado ) { // me quedo con la unidad i (no asignada aún) que mayor valor tiene en la localización 'j'
                masVisitado = memLargoPlazo[i][j];
                LocalizacionMasVisitada = j;
                unidadCorrespondiente = i;
            }
        }
        masVisitado = -1;
        solAct[unidadCorrespondiente] = LocalizacionMasVisitada; //genero una nueva solAct según los más visitados
        vectorMarcaje[unidadCorrespondiente] = false; // marco en el vector de marcaje
    }

    log << "\nSolAct Despues de intensificar" << std::endl;

    for(int i = 0; i < tamSolAct; i++) {
        log << solAct[i] << " ";
    }

    valorActual = Auxiliar::CosteFuncion(solAct); //calculo el coste de la nueva solución
    log << "\n" << "nuevo valorAct: " << valorActual << std::endl;


}

void BusquedaTabu::diversificar() {

    log << "solAct Antesssss" << std::endl;

    for(int i = 0; i < tamSolAct; i++) {
        log << solAct[i] << " ";
    }

    std::vector<bool> vectorMarcaje(tamSolAct); // vector para evitar poner dos localizaciones en la misma unidad
    int LocalizacionMenosVisitado, unidadCorrespondiente, menosVisitado = INT_MAX; // atributos de marcaje del menos visitado
    for(int i = 0; i < tamSolAct; i++){
        vectorMarcaje[i] = true;
    }

    for(int j = 0; j < tamSolAct; j++){
        for(int i = 0; i < tamSolAct; i++) {
            if( vectorMarcaje[i] && memLargoPlazo[i][j] < menosVisitado ) { // me quedo con la unidad i (no asignada aún) que menor valor tiene en la localización 'j'
                menosVisitado = memLargoPlazo[i][j];
                LocalizacionMenosVisitado = j;
                unidadCorrespondiente = i;
            }
        }
        menosVisitado = INT_MAX;
        solAct[unidadCorrespondiente] = LocalizacionMenosVisitado; //genero una nueva solAct con las localizaciones menos visitadas
        vectorMarcaje[unidadCorrespondiente] = false;
    }

    log << "\nSolAct Despues de diversificar" << std::endl;

    for(int i = 0; i < tamSolAct; i++) {
        log << solAct[i] << " ";
    }

    valorActual = Auxiliar::CosteFuncion(solAct); //calculo el coste de la nueva solción
    log << "\n" << "nuevo valorAct: " << valorActual << std::endl;


}

void BusquedaTabu::printMemoriasTabu(int c) {

    log << "ITERACIÓN: " << c << " SolAct: " << std::endl;

    for(int i = 0; i < tamSolAct; i++) {
        log << solAct[i] << " " ;
    }

    //todo encapsular logs

    log << "\n\nEstado memoria de  soluciones:" << std::endl;

    for(int i = 0; i < tenenciaTabu; i++) {
        for (int j = 0; j < tamSolAct; j++) {
            log << memSoluciones[i][j] << " " ;
        }
        log << std::endl;
    }

    log << "\nMovimientos  tabú activos:" << std::endl;
    if( !posicionesConTabuActiva.empty() ) {
        for (std::set<std::pair<int, int>>::iterator it = posicionesConTabuActiva.begin();
             it != posicionesConTabuActiva.end(); ++it) {
            log << it->first << "-" << it->second << " Tenencia tabú actual: " << memMovimientos[it->first][it->second] << "\n";
        }
    }
    log << std::endl;
}

void BusquedaTabu::movermeAMejorPeor(std::vector<int> &mejorPeor, int valorMejorPeor) {
    if(valorMejorPeor != INT_MAX) { // para evitar errores
        log << "En la exploración del vecindario NO he mejorado solAct, asi que me muevo al mejor peor: "
            << valorMejorPeor << std::endl;
        solAct = mejorPeor; // me muevo al mejor peor
        valorActual = valorMejorPeor;
        log << "La DLB se ha llenado, la reinicializo" << std::endl;
        generaDLBRandom(); //si no he mejorado la solAct -> la DLB está llena y tengo que reiniciarla
    }
}

bool BusquedaTabu::actualizarValorDelMejor() {

    if(valorActual < valorMejorMomento ) { //compruebo si es la mejor solución

        log << "Mejoro el mejorValor: " << valorMejorMomento << " -> ";
        mejorMomento = solAct;
        valorMejorMomento = valorActual;
        estancamiento = 0;
        log << valorMejorMomento << "\n" << "Estancamiento: " << estancamiento << std::endl;
        if(valorActual < valorMejorGlobal){ // compruebo si es la mejor solución global independiente de oscilación

            log << "Mejoro el mejor global: " << valorMejorGlobal << " -> ";
            mejorGlobal = solAct;
            valorMejorGlobal = valorActual;
            log << valorMejorMomento << std::endl;

        }
        return true;

    }

    return false;

}

void BusquedaTabu::printSolucion(int c) {

    log << "\n" << "Número total de vueltas: " << c << std::endl;
    log << "Mejor solución global obtenida: " << valorMejorGlobal << std::endl;
    for(int i = 0; i < tamSolAct; i++) {
        log << mejorGlobal[i] << " " ;
    }
    log << "\n" << "Estado final de DLB: " << std::endl;

    for(int i = 0; i < tamSolAct; i++) {
        if(DLB[i])
            log << 1 << " " ;
        else
            log << 0 << " " ;
    }
    log << "" << std::endl;

}

const std::vector<int> &BusquedaTabu::getMejorGlobal() const {
    return mejorGlobal;
}
