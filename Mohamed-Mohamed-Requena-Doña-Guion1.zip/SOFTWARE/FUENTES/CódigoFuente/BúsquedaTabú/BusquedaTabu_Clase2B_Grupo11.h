//
// Created by yessi on 05/10/2023.
//

#ifndef PR1META_BUSQUEDATABU_H
#define PR1META_BUSQUEDATABU_H

#include <vector>
#include <set>
#include <fstream>

class BusquedaTabu {
private:
    std::vector<int> solAct; //solcuión actual
    std::vector<int> mejorMomento; // mejor solución encontrada(se reinicia tras oscilar)
    std::vector<int> mejorGlobal; // mejor solución encontrada independientemente de oscilación
    std::vector<int> solucionEjecucionAnterior;
    std::vector<bool> DLB;
    std::vector<std::vector<int>> memMovimientos; // Matriz Implícita
    std::vector<std::vector<int>> memSoluciones; // Explicita -> lista circular de vectores soluciones simulada con un vector mediante el operador %
    std::set<std::pair<int,int>> posicionesConTabuActiva; // conjunto auxiliar que almacena los movimientos(par i-j) que son tabú actualmente
    std::vector<std::vector<int>> memLargoPlazo; // Matriz de frecuencias
    int valorActual; // valor asociado a la solución actual
    int valorMejorMomento; // valor asociado al mejor del momento
    int valorMejorGlobal; // valor asociado al mejor global
    int valorEjecucionAnterior; // valor previo a oscilación
    int tamSolAct; // tamaño del conjunto de datos
    int tenenciaTabu;
    int estancamiento;
    std::ofstream log;

    /*
     * Facticble: Método que calcula el coste del vecino respecto a la posición actual
     * @param: int i, int j -> posiciones que sufren el swap
     * @return: devuelve el coste asociado a dicho vecino
     */
    int factible(int i, int j);

    /*
     * aplicarMovimiento: Método que aplica el swap sobre el vector y que actualiza su coste asociado
     * @param i,j: posiciones que sufren el swap
     * @param coste: coste asociado a dicho vecino
     * @param vCompare, valorCompare[IN/OUT]: vector actual y coste asociado
     * @post: actualizo vCompare con el vector generado y actualizo su respectivo coste
     */
    void aplicarMovimiento(int i, int j, int coste, std::vector<int>& vCompare, int &valorCompare);

    /*
     * Tabu: Comprueba que el vecino de 'solAct' no es ni movimiento ni solcuión tabú
     * @param i,j: posiciones en las que hacer swap
     */
    bool Tabu(int iSwap, int jSwap);

    /*
     * generaTabú: Genero un vecino de 'solAct', en caso de ser mejor que 'solAct' me muevo a él, sino devuelvo el mejor vecino encontrado
     * @param indiceDLBInicio: valor que indica a partir de que posición comienzo a explorar los swap
     * @param mejorPeor, valorMejorPeor[IN/OUT]: vector solución y coste asociado al mejorPeor vecino
     * @param parI[IN/OUT], parJ[IN/OUT]: posiciones en las que se ha hecho el swap y que por tanto ha generado el vecino
     * @post: en caso de encontrar un vecino mejor que 'solAct', actualizo dicho vector y su valor asociado,
     *      en caso contrario se actualiza 'mejorPeor' y su 'valorMejorPeor' con el mejor vecino encontrado y su respectivo coste
     * @return: se devuelve un bool indicando si se ha mejorado la solAct(true) o si no se ha mejorado
     */
    bool generaVecino(int indiceDLBInicio, std::vector<int>& mejorPeor, int &valorMejorPeor, int& parI, int& parJ);

    /*
     * decrementaTenenciaTabu: Método que se encarga de decrementar en 1 el coste asociado a las movimiento tabú
     */
    void decrementarTenenciaTabu();

    /*
     * Método que modifica el valor de la DLB con probabilidad del 50% del generar un 0 o 1 en cada posición
     * @post: la DLB se ha modificado
     */
    void generaDLBRandom();

    /*
     * Método que actualiza las memorias tabú a corto y largo plazo
     * @param posI, posJ: posiciones a marcar como tabú en la memoria de movimientos
     * @param mejoraSolAct: bool que indica si me he movido a una solución mejor que la actual(true) o no
     * @param mejorPeor: vector solución del mejorPeor
     * @param posActual: posición en la que se insertará la solución en la memoria de soluciones
     * @post: se pone en memMovimientos[posI][posJ] el valor 'tenenciaTabu', se actualiza la memoria de soluciones
     *  con solAct si 'mejoraSolAct' es true o con mejorPeor en caso contrario
     *
     */
    void actualizarMemorias(int posI, int posJ, bool mejoraSolAct, std::vector<int> &mejorPeor, int posActual);

    /*
     * Se reinicia las estructuras de almacenaiento y atributos, además de intensificar o diversificar según una probabilidad
     * @post: se ha generado una nueva solAct y su respectivo valor, además de reiniciarse las memorias y atributos para reflejar
     *  un nuevo "comienzo" en la ejecución
     */
    void oscilacion();

    /*
     * Se genera un nuevo vector solución priorizando la asignación de las localizaciones más visitadas
     * @post: solAct y valorActual reflejan el nuevo vector solución y su respectivo coste
     */
    void intensificar();

    /*
     * Se genera un nuevo vector solución priorizando la asignación de las localizaciones menos visitadas
     * @post: solAct y valorActual reflejan el nuevo vector solución y su respectivo coste
     */
    void diversificar();

    /*
     * Se actualiza la memoria a largo plazo en base al vector solución
     * @param solAct: vector solución
     * @post: la memoria se actualiza reflejando las localizaciones visitadas por cada unidad de dicho vector
     */
    void actualizarMemLargoPlazo(std::vector<int> &v);

    /*
     * Método que imprime en el log las diferentes memorias tabú a corto plazo usadas
     */
    void printMemoriasTabu(int c);

    /*
     * Método que imprime en el log información relacionada con la solución del algortimo
     */
    void printSolucion(int c);

    /*
     * Método encargado de actualizar la solución actual y su respectivo coste según el mejorPeor
     * @param mejorPeor, valorMejorPeor: vector solución del mejorPeor y su coste
     * @post: actualizo solAct y valorAct con mejorPeor y valorMejorPeor respectivamente
     */
    void movermeAMejorPeor(std::vector<int> &mejorPeor, int valorMejorPeor);

    /*
     * Método que comprueba si el valor de la solución actual es mejor que el de mejor momento y que del global
     * @post: en caso de ser solAct mejor que el mejor del momento actualizo su vector solución y su valor asociado,
     *  en caso de ser mejor que el global hago lo mismo, pero sobre el vector y la solución del mejor global
     */
    bool actualizarValorDelMejor();

public:
    BusquedaTabu(std::vector<int> &vIni, std::string nombreLog);
    ~BusquedaTabu();
    int executeBusquedaTabu();
    const std::vector<int> &getMejorGlobal() const;
};


#endif //PR1META_BUSQUEDATABU_H
